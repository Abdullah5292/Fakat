import React from "react";


export const TrustedBy = () => {
    return (
        <div className="w-full bg-white py-[50px] bg-white ">
            <div className=" max-w-[1480px] m-auto max-w-[600px]">
                <h1 className="text-3xl font-bold text-center text-fakatred">Trusted by over 500 students at IBA</h1>
                <p className="text-center text-fakatred text-1xl ">Students from all programs choose Fakat with their treasured belongings</p>
            </div>
        </div>
    );

}